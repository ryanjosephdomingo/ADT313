import React, { useState } from 'react';

export default function Problem4() {
  const [formData, setFormData] = useState({
    name: '',
    yearlevel: '',
    course: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault(); 
    console.log(formData); 
    alert(JSON.stringify(formData, null, 2)); 
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <div style={{ display: 'block' }}>
          Name: 
          <input
            type='text'
            name='name'
            value={formData.name}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          <p>Yearlevel:</p>
          <input
            type='radio'
            id='firstYear'
            name='yearlevel'
            value='First Year'
            checked={formData.yearlevel === 'First Year'}
            onChange={handleChange}
          />
          <label htmlFor='firstYear'>First Year</label>
          <br />
          <input
            type='radio'
            id='secondYear'
            name='yearlevel'
            value='Second Year'
            checked={formData.yearlevel === 'Second Year'}
            onChange={handleChange}
          />
          <label htmlFor='secondYear'>Second Year</label>
          <br />
          <input
            type='radio'
            id='thirdYear'
            name='yearlevel'
            value='Third Year'
            checked={formData.yearlevel === 'Third Year'}
            onChange={handleChange}
          />
          <label htmlFor='thirdYear'>Third Year</label>
          <br />
          <input
            type='radio'
            id='fourthYear'
            name='yearlevel'
            value='Fourth Year'
            checked={formData.yearlevel === 'Fourth Year'}
            onChange={handleChange}
          />
          <label htmlFor='fourthYear'>Fourth Year</label>
          <br />
          <input
            type='radio'
            id='fifthYear'
            name='yearlevel'
            value='Fifth Year'
            checked={formData.yearlevel === 'Fifth Year'}
            onChange={handleChange}
          />
          <label htmlFor='fifthYear'>Fifth Year</label>
          <br />
          <input
            type='radio'
            id='irregular'
            name='yearlevel'
            value='Irregular'
            checked={formData.yearlevel === 'Irregular'}
            onChange={handleChange}
          />
          <label htmlFor='irregular'>Irregular</label>
          <br />
        </div>
        <div style={{ display: 'block' }}>
          Course:
          <select
            name='course'
            value={formData.course}
            onChange={handleChange}
          >
            <option value=''>Select a course</option>
            <option value='BSCS'>BSCS</option>
            <option value='BSIT'>BSIT</option>
            <option value='BSCpE'>BSCpE</option>
            <option value='ACT'>ACT</option>
          </select>
        </div>
        <button type='submit'>Submit</button>
      </form>
      <pre>{JSON.stringify(formData, null, 2)}</pre> { }
    </>
  );
}